time java com.drin.java.ClusterInterface database_iso_ids > database_oh_clusters_agglomerative.timed_1.csv
time java com.drin.java.ClusterInterface database_iso_ids > database_oh_clusters_agglomerative.timed_2.csv
time java com.drin.java.ClusterInterface database_iso_ids > database_oh_clusters_agglomerative.timed_3.csv
time java com.drin.java.ClusterInterface database_iso_ids > database_oh_clusters_agglomerative.timed_4.csv
