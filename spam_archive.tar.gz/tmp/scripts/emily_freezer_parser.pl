open(IN, '<Freezer Sample Log.csv');
@input = <IN>;
close(IN);

@sql_insert_records = ();
for $record (@input) {
   if ($record =~ m/(\d+),(\w)\s*(\w)\s*(\d+)-(\d+)/) {
      $isoID = $1;
      ($subject, $swab_type) = ($2, $3);
      ($swab_time, $swab_sample) = ($4, $5);

      $subject = lc($subject);
      $swab_type = lc($swab_type);

      print(OUT "Hu-$isoID [Subject $subject]: $swab_type -> ($swab_time, $swab_sample)\n");
      push(@sql_insert_records, "('Hu-$isoID', '$subject', '$swab_type', $swab_time, $swab_sample)");
   }
   else {
      print("$record\n");
   }
}

open(OUT, '>emily_meta.sql');
print(OUT "insert into emily_meta(isoID, subject, swab_type, swab_time, swab_sample) VALUES ");
print(OUT join(',', @sql_insert_records).";");
close(OUT);
