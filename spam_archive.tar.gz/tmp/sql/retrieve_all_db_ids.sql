select distinct isoID from Isolates join Pyroprints p1 using (isoID) join Pyroprints p2 using (isoID) where p1.appliedRegion != p2.appliedRegion and p2.pyroID > p1.pyroID;
